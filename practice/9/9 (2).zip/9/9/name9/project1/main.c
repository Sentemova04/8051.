#include <8051.h>

interrupt void prerivanie() { 
	P35 = !P35; 

}

void main()
{
	IE = 0;
	IE_BITS.B7 = 1; 
	IE_BITS.B0 = 1;
	TCON_BITS.B0 = 1; 

	P1 = 0;
	P2 = 0;
	P3 = 0;
	while (1) {
		P37 = 1; 
		P37 = 0;

		while (P36 == 1); 
		P2 = P1; 
	}

}
