#include <8051.h>

void Timer0_Mode3_Init() {
    TMOD &= 0xF0;   
    TMOD |= 0x03;   
    TF0 = 0;        
    TF1 = 0;        
    TR0 = 0;        
    TR1 = 0;        
    TL0 = 0x00;     
    TH0 = 0x00;     
    TR0 = 1;       
    TR1 = 1;       
}

void delay_250us(unsigned int count) {
    unsigned char reload_value = 256 - 250; 
    while (count--) {
        TF0 = 0;
        TL0 = reload_value;
        while (!TF0);
    }
}

void vertical_line_up(unsigned char min_level, unsigned char mid_level, int t) {
     int step, i;
    if (t <= 0) t = 1; 
    step = t / 1;
    for (i = 0; i < t; i += step) {
        P0 = min_level;
        P0 = mid_level;
        
    }
}

void smooth_rise(unsigned char start_level, unsigned char end_level, unsigned int step, int t) {
    int i;
    if (t <= 0) t = 1;
    for (i = 0; i < t; i += step) {
        P0 = (int)(i * (end_level - start_level) / t) + start_level;
    delay_250us(1);
}
}
void smooth_fall(unsigned char start_level, unsigned char end_level, unsigned char step) {
    int i;
    for (i = start_level; i >= end_level; i -= step) {
        P0 = i;
    delay_250us(1);
}
}
void plateau(unsigned char level, unsigned int duration_250us) {
    unsigned int i;
    for (i = 0; i < duration_250us; i++) {
        P0 = level;
    delay_250us(1);
}
}
void vertical_line_down(unsigned char min_level) {
    P0 = min_level;
}

void main() {
    unsigned char min_level = 0;
    unsigned char mid_level = 128;
    unsigned char low_mid_level = 64;
    unsigned char max_level = 255;

    Timer0_Mode3_Init();

    while (1) {
        vertical_line_up(min_level, mid_level, 1);       
        smooth_rise(mid_level, max_level, 20, 60);      
        smooth_fall(max_level, low_mid_level, 30);      
        vertical_line_up(low_mid_level, mid_level, 1);   
        plateau(mid_level, 3);                           
        vertical_line_down(min_level);                     
        plateau(min_level, 6);                           
    }
}
