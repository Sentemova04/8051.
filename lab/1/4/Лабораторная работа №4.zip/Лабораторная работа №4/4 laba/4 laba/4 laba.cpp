﻿#include <iostream>
#include <locale.h>
#include "c_code.c"
extern "C" void     asm_code_1(int N, double* massiv);

int main() 
{
    // 18 вариант
    setlocale(LC_ALL, "Russian");
    double mass[100];
    int N;
    std::cout << "Введите значение N: ";
    std::cin >> N;
    for (int i = 0; i < N; i++) {
        std::cout << "введите значение массива (i=" << i << "): ";
        std::cin >> mass[i];
    }
    asm_code_1(N, mass);
    std::cout << "Полученный массив:";
    for (int i = 0; i < N; i++) {
        if (mass[i] == INFINITY)
            std::cout << std::endl << "mass[" << i << "] бесконечен";
        else if (_isnan(mass[i]))
            std::cout << std::endl << "mass[" << i << "] не определён";
        else
            std::cout << std::endl << "mass[" << i << "]: " << mass[i];

        //printf_s("%.1f", (float)i / 10);
        //std::cout << ":\t";
        //printf_s("%.5f", arr[i]);
        //std::cout << std::endl;
    }


    std::cout << "\n\n\n\t";
    system("pause");
}
