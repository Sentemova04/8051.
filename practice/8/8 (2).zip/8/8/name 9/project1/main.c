#include <8051.h>

void Timer0_Delay_us(unsigned int us) {
    unsigned int reload = 65536 - us; 

    TMOD &= 0xF0;      
    TMOD |= 0x01;      

    TH0 = reload >> 8; 
    TL0 = reload & 0xFF; 

    TF0 = 0;           
    TR0 = 1;           

    while (TF0 == 0);  

    TR0 = 0;           
    TF0 = 0;           
}
void main() {
    int i;
    unsigned char min_level = 0;
    unsigned char mid_level = 128;
    unsigned char low_mid_level = 64;
    unsigned char high_level = 128;
    unsigned char max_level = 255;

    while (1) {
        P0 = min_level;
        P0 = mid_level;
        
        for (i = mid_level; i <= max_level; i += 5) {
            P0 = i;
            Timer0_Delay_us(25);
        }

        for (i = max_level; i >= low_mid_level; i -= 5) {
            P0 = i;
            Timer0_Delay_us(25);
        }

        P0 = high_level;
        Timer0_Delay_us(750);

        for (i = 0; i < 10; i++) {
            P0 = high_level;
            Timer0_Delay_us(25);
        }

        P0 = min_level;
        Timer0_Delay_us(1500);

        for (i = 0; i < 20; i++) {
            P0 = min_level;
            Timer0_Delay_us(25);
        }
    }
}
